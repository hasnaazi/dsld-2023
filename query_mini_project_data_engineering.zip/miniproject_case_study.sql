//-- A. PRODUCT ANALYSIS
--- menganalisa trend penjualan tiap bulan berdasarkan produknya, jenis customer, jenis produk
-- 1. ANALISA TREN PENJUALAN TIAP BULAN
select distinct year, month, ProductName,banyak_order from(
	select year, month, b.ProductName ProductName, count(ProductName) over (partition by year,month, ProductName) banyak_order from(
		select year(OrderDate) year, month(OrderDate)month,a.OrderID, ProductID from(
			select OrderID, OrderDate from Orders
			)a
			left join
			(
				select OrderID, ProductID from [Order Details]
			)b on a.OrderID = b.OrderID
		)a
		left join
		(
			select ProductID, ProductName from Products
		)b on a.ProductID = b.ProductID
)x	
order by 1,2,4


-- 2. ANALISA JENIS CUSTOMER
select distinct year, month,x.OrderID,CompanyName,
ContactTitle, round(sum(b.harga_akhir) over (partition by x.OrderID),2) Final_Price from(
	select year(a.OrderDate) year, month(a.OrderDate) month, OrderID,b.CompanyName CompanyName, 
		b.ContactTitle ContactTitle from(
		select OrderID, CustomerID, OrderDate from Orders
		)a
		left join
		(
			select CustomerID, CompanyName, ContactTitle from Customers
		)b on a.CustomerID=b.CustomerID
)x
left join
(
	select a.orderID,pembelian-(pembelian*Discount) as harga_akhir  from(
		select orderID,UnitPrice*Quantity as pembelian,Discount from [Order Details]
	)a
)b on x.OrderID = b.OrderID
order by year, month;


-- 3. ANALISA JENIS PRODUCT
with product_temp as(
	select year(b.OrderDate)year, month(b.OrderDate)month,a.OrderID, a.ProductID, c.CategoryName CategoryName,
	row_number() over (partition by year(b.OrderDate),month(b.OrderDate),CategoryName order by a.OrderID)count from(
		select OrderID,ProductID from [Order Details]
		)a 
		left join
		(
			select OrderID, OrderDate from Orders
		)b on a.OrderID = b.OrderID
		left join
		(
			select ProductID, CategoryName from(
				select ProductID, CategoryID from Products
				)a
				left join
				(
					select CategoryID, CategoryName from Categories	
				)b on a.CategoryID = b.CategoryID
		)c on a.ProductID = c.ProductID
)

select distinct year, month,CategoryName,count(CategoryName) OVER (PARTITION BY year,month,CategoryName) as banyak_order from product_temp
order by 1,2,4 desc;


//-- B. EMPLOYEE ANALYSIS
--- Mencari informasi pegawai yg paling banyak berurusan dengan order
select Name, Title, banyak_order from(
	select distinct EmployeeID, count(OrderID) OVER (PARTITION BY EmployeeID) as banyak_order from Orders
	) a
	left join
	(
		select EmployeeID, concat(FirstName,' ', LastName) as Name,Title from Employees
	)b on a.EmployeeID = b.EmployeeID
order by 3 Desc;

//-- C. SHIPPER ANALYSIS
--- Mencari informasi orderan paling banyak dikirim ke kota mana, dengan shipper apa
select distinct ShipperID, CompanyName, ShipCountry, count(ShipCountry) over (partition by CompanyName,ShipCountry) from(
	select ShipperID, CompanyName from Shippers
	)a
	left join
	(
	select OrderID, ShipVia, ShipCountry from orders
	)b on a.ShipperID = b.ShipVia
order by 1,2,4 desc;


