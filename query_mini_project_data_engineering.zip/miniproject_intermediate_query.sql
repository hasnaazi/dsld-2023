
//-- NO 1
-- jumlah customer tiap bulan yang melakukan order pada tahun 1997
select month(OrderDate) as Bulan,count(CustomerID) jumlah_customer 
from dbo.Orders where year(OrderDate) = 1997 
group by month(OrderDate);

//-- NO 2
-- nama employee yang termasuk Sales Representative
select CONCAT(FirstName,' ',LastName) as Nama from Employees where Title = 'Sales Representative';


//-- NO 3
--  top 5 nama produk yang quantitynya paling banyak diorder pada bulan Januari 1997
select row rangking_top5, a.ProductID,c.ProductName,count count_order
from(
	select row_number() over(order by count(b.ProductID) desc) as row,b.ProductID, count(b.ProductID) count from
		(
		select OrderID, OrderDate from Orders
		)a
		left join
		(
		select 'top_5' top5,OrderID, ProductID from [Order Details]
		)b on a.OrderID = b.OrderID
	where year(a.OrderDate) = 1997 and month(a.OrderDate) = 1 group by ProductID 
	)a
	left join
	(
		select ProductID, ProductName from Products
	)c on a.ProductID = c.ProductID
where row <= 5 order by count desc;

//-- NO 4
-- nama company yang melakukan order Chai pada bulan Juni 1997
select b.CompanyName 
from(
	select OrderID,OrderDate,CustomerID from Orders
	)a
left join
(
	select CustomerID,CompanyName from Customers
)b on a.CustomerID= b.CustomerID
left join
(
	select a.OrderID,a.ProductID,b.ProductName 
	from(
		select OrderID,ProductID from [Order Details]
		)a
	left join(
		select ProductID,ProductName from Products 
		)b on a.ProductID = b.ProductID
)c on a.OrderID=c.OrderID
where year(OrderDate)=1997 and month(OrderDate)=6 and c.ProductName = 'Chai';


//--NO 5
--jumlah OrderID yang pernah melakukan pembelian (unit_price dikali quantity) <=100, 100<x<=250, 250<x<=500, dan >500
select keterangan,count(distinct OrderID) jumlah_order_id from(
	select case
		when a.pembelian <=100 then '<=100'
		when a.pembelian>100 and a.pembelian<=250 then '100<x<=250'
		when a.pembelian>250 and a.pembelian<=500 then '250<x<=500'
		when a.pembelian>500 then '>500'
	end keterangan, OrderID from(
		select orderID,UnitPrice*Quantity as pembelian from [Order Details]
		)a
)a group by keterangan;


//--NO 6
-- Company name pada tabel customer yang melakukan pembelian di atas 500 pada tahun 1997.
select distinct(b.CompanyName) from(
	select OrderID, CustomerID, OrderDate from Orders
	)a
left join
(
	select CustomerID, CompanyName from Customers
)b on a.CustomerID = b.CustomerID
left join
(
	select OrderID,UnitPrice*Quantity as pembelian from [Order Details]
)c on a.OrderID = c.OrderID
where c.pembelian >500 and year(OrderDate)=1997;

//-- NO 7
-- nama produk yang merupakan Top 5 sales tertinggi tiap bulan di tahun 1997.
select bulan, ProductName, Quantity, top5sales from(
	select tahun,bulan,b.ProductName ProductName, a.Quantity Quantity, 
	ROW_NUMBER () over (PARTITION by month(c.OrderDate) order by Quantity DESC) as top5sales from(
		select OrderID,ProductID, Quantity from [Order Details]
		)a
	left join
	(
		select ProductID,ProductName from Products 
	)b on a.ProductID = b.ProductID
	inner join
	(
		select OrderID, OrderDate, year(OrderDate)tahun,month(OrderDate)bulan from Orders
	)c on a.OrderID = c.OrderID
	where tahun = 1997
)a
where top5sales<=5
order by 1,3 DESC;

//--NO 8
-- Membuat view untuk melihat Order Details yang berisi OrderID, ProductID, ProductName, UnitPrice, Quantity, Discount, Harga setelah diskon.
create or ALTER view dbo.create_view AS
	select OrderID, a.ProductID, b.ProductName, UnitPrice, Quantity, Discount,pembelian-(pembelian*Discount) as harga_akhir from(
		select *, Unitprice*Quantity as pembelian from [Order Details] 
		) a
	left join
		(
		select ProductID, ProductName from Products
		)b on a.ProductID = b.ProductID;


//-- NO 9
--  memanggil CustomerID, CustomerName/company name, OrderID, OrderDate, RequiredDate, ShippedDate jika terdapat inputan CustomerID tertentu.
select a.CustomerID, CompanyName,OrderDate, RequiredDate, ShippedDate from (
	select CustomerID, CompanyName from Customers)a
	left join
	(
	select OrderID, CustomerID, OrderDate, RequiredDate, ShippedDate from Orders
	)b on a.CustomerID = b.CustomerID


